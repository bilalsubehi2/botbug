/*


BASE : RUZUREN
RECODE : SWIPER FVCK
ENCRYPT : TYPE HARD
NOT DELET SUMBER
NOT DELET CREDIT
NOT FOR SELL

Whatsapp: https://wa.me/6283895883216
 Telegram: https://t.me/SwiperFvck2
 Github: https://github.com/swipfvck29
 Website: https://linktr.ee/swiperfvck
 Channel: https://whatsapp.com/channel/0029Vb5dUs07oQhjMXztZw2o
 
 
*/

const fs = require('fs')

// ========= Setting Owner ========= //
global.owner = "6283895883216@s.whatsapp.net"

// ========= Setting Channel ========= //
global.namasaluran = "𝗦𝗪𝗜𝗣𝗘𝗥 𝗙𝗩𝗖𝗞 || 𝗙𝗩𝗖𝗞𝗘𝗥𝗦 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡"
global.idsaluran = "120363418557093738@newsletter@newsletter"
global.linksaluran = "https://whatsapp.com/channel/0029Vb5dUs07oQhjMXztZw2o"

// ========= Setting Status ========= //
global.status = true
global.welcome = true
global.antispam = true
global.autoread = true
global.prefa = ['','!','.',',','🐤','🗿']

// ========= Setting WM ========= //
global.packname = 'Fvckers🏴'
global.author = 'SwiperFvck'


global.gcount = {
    prem : 500,
    user: 15
}

//limit
global.limitCount = 10,

//message 
global.mess = {
    group: "ngapain? khusus grup njrr",
    admin: "ngapain? khusus admin njrr",
    owner: "apalah, bukan owner",
    premium: "bukan user premium njrr",
    botadmin: "bot bukan admin",
    limited: "limitmu habis, kembali besok/sore nanti"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
